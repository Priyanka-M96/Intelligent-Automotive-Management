<?php
$conn=mysql_connect("localhost","root","","bus_system") or die(mysql_connect_error());
if($conn)
?>